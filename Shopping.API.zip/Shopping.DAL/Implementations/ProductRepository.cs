﻿using Shopping.DAL.Interfaces;
using Shopping.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.DAL.Implementations
{
    public class ProductRepository : IProductRepository
    {

        public Task<List<Product>> GetProducts()
        {
            var result= ProductGlobalList.GetList();
            return Task.FromResult<List<Product>>(
                result);
        }
        public Task<ResponseModel> AddProduct(Product product)
        {
            var result = ProductGlobalList.add(product);
            return Task.FromResult(result);
        }

        public Task<ResponseModel> UpdateProduct(Product product)
        {
            var result = ProductGlobalList.update(product);
            return Task.FromResult(result);
        }

        public Task<ResponseModel> DeleteProduct(int Id)
        {
            var result = ProductGlobalList.Delete(Id);
            return Task.FromResult(result);
        }
    }
}
