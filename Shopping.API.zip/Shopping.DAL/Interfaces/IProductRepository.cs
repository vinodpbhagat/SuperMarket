﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Shopping.Domain.Models;

namespace Shopping.DAL.Interfaces
{
    public interface IProductRepository
    {
        Task<List<Product>> GetProducts();
        Task<ResponseModel> AddProduct(Product product);
        Task <ResponseModel> UpdateProduct(Product product);
        Task<ResponseModel> DeleteProduct(int Id);
    }
}
