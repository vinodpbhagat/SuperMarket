﻿using Shopping.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.DAL
{
    static class ProductGlobalList
    {

        static List<Product> productList;

        static ProductGlobalList()
        {
            

            productList = new List<Product>
                {
                  new Product { Id = GenerateRandomNumber(),CategoryName = "Electronics",Title = "WD 2TB Elements Portable External Hard Drive - USB 3.0 " ,Description="USB 3.0 and USB 2.0 Compatibility Fast data transfers Improve PC Performance High Capacity", Price = 849.95 , CreatedAt = DateTime.UtcNow },
                 new Product { Id = GenerateRandomNumber(),CategoryName = "Electronics",Title = "SanDisk SSD PLUS 1TB Internal SSD - SATA III 6 Gb/s" ,Description="Easy upgrade for faster boot up, shutdown, application load and response (As compared to 5400 RPM SATA 2.5” hard drive; ", Price = 498.95 , CreatedAt = DateTime.UtcNow },
                    new Product { Id = GenerateRandomNumber(),CategoryName = "Fashion",Title = "Mens Casual Slim Fit" ,Description ="The color could be slightly different between on the screen and in practice. / Please note that body builds vary by person, therefore, detailed size information should be reviewed below on the product description.", Price = 49.95 , CreatedAt = DateTime.UtcNow  },
                 new Product { Id = GenerateRandomNumber(),CategoryName = "Fashion",Title = "Mens Cotton Jacket", Description="great outerwear jackets for Spring/Autumn/Winter, suitable for many occasions, such as working, hiking, camping, mountain/rock climbing, cycling, traveling or other outdoors. ", Price = 15.99  , CreatedAt = DateTime.UtcNow },
                   new Product { Id = GenerateRandomNumber(),CategoryName = "Jewllery",Title = "ohn Hardy Women's Legends Naga Gold" , Description="From our Legends Collection, the Naga was inspired by the mythical water dragon that protects the ocean's pearl",Price = 695 , CreatedAt = DateTime.UtcNow  },
                 new Product { Id = GenerateRandomNumber(),CategoryName = "Jewllery",Title = "Solid Gold Petite Micropave " ,Description="Satisfaction Guaranteed. Return or exchange any order within 30 days.Designed and sold by Hafeez Center in the United States", Price = 649.95 , CreatedAt = DateTime.UtcNow  },
                
                };

     
        }

        public static ResponseModel add(Product product)
        {
            ResponseModel response = new ResponseModel();

            var isProductExists = productList.SingleOrDefault(p => p.CategoryName == product.CategoryName &&  p.Title ==product.Title);

            if (isProductExists == null)
            {
                productList.Add(new Product()
                {

                    Id = GenerateRandomNumber(),
                    CategoryName = product.CategoryName,
                    Title = product.Title,
                    Description = product.Description,
                    Price = product.Price,
                    CreatedAt = DateTime.UtcNow,
                });
                response.message = "Product Added successfully.";
                response.statusCode = 200;
            }
            else
            {
                response.message = "Product already added.";
                response.statusCode = 400;
            }
            return response;

        }

        public static List<Product> GetList()
        {
            return productList.OrderByDescending(d => d.CreatedAt).ToList(); ;
        }

        public static ResponseModel update(Product product)
        {
            ResponseModel response = new ResponseModel();

            var result = productList.SingleOrDefault(p => p.Id == product.Id);
            if(result !=null)
            {

                result.CategoryName = product.CategoryName;
                result.Title = product.Title;
                result.Description = product.Description;
                result.Price = product.Price;
                response.message = "Product updated successfully.";
                response.statusCode = 200;
            }
            else
            {
                response.message = "Product does not exists.";
                response.statusCode = 400;
            }

            return response;


        }
        public static ResponseModel Delete(int Id)
        {
            ResponseModel response = new ResponseModel();

            var result = productList.SingleOrDefault(p => p.Id == Id);
            if (result != null)
            {
                productList.Remove(result);
                response.message = "Product deleted successfully.";
                response.statusCode = 200;
            }
            else
            {
                response.message = "Product does not exists.";
                response.statusCode = 400;
            }

            return response;
        }

        public static int GenerateRandomNumber()
        {
            Random random = new Random();
            return random.Next(1000, 10000);
        }
    }
}
