import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationStart, Router } from '@angular/router';
import { filter, map } from 'rxjs/operators';


import {FormGroup, FormBuilder, Validators} from "@angular/forms";
import { ApiService } from 'src/app/service/api.service';
import { addProductUrl ,updateProductUrl } from 'src/app/service/api.urls';
import { Product } from 'src/app/models/Product';
import { ResponseModel } from 'src/app/models/ResponseModel';
import { ProductService } from 'src/app/service/product.service';
import { Observable, Subscription } from 'rxjs';


@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss'],
})
export class AddProductComponent implements OnInit {
  productForm: FormGroup;
  isDisplayMessage:boolean= false;
  isSuccess:boolean= true;
  isSuccessMessage:string ="";
  errors:any;
  isAdd:boolean=true;
  getApiUrl:string="";
  productValue:any;
  message:string ="";
  lableText : string ="";
  btnText : string ="";

  constructor(private fb: FormBuilder,private route: ActivatedRoute,private router: Router,private api : ApiService ,private productService : ProductService ) {
    this.productForm = this.fb.group({
      id: [0],
      categoryName: ['', Validators.required],
      title: [''],
      description: ['', Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(1000)])],
      price: ['', Validators.compose([Validators.required])],
    });
  }
  ngOnInit(): void {
    this.lableText = this.isAdd == true ? "Add":"Update";
    this.btnText = this.isAdd == true ? "Submit":"Update";
  }

  ngAfterViewInit(){
    this.productService.getProductData().subscribe((data : any) => {
      if(data !=null)
      {
        const updateObject : Product = {
          id: data.id,
          title: data.title,
          price: data.price,
          description: data.description,
          categoryName: data.categoryName,
        };
        this.productForm.patchValue(updateObject);
        this.isAdd=false;
      }
    });
  }
  saveProduct(values:any){
    if (this.productForm.invalid) {
      return;
    }
    this.getApiUrl = this.isAdd == true ? addProductUrl  : updateProductUrl;
     this.apiCall(this.getApiUrl,values).subscribe((result:any)=>{
          this.isDisplayMessage=true
          this.isSuccess=true;
          this.isSuccessMessage=result["message"];
     },(error:any) =>{
      this.isDisplayMessage=true
          this.isSuccess=false;
          this.isSuccessMessage=error;
     });
  }
  onReset() {
    this.productForm.reset();
   }
   apiCall(getApiUrl:any,values:Product) :any
   {
    return this.isAdd == true ? this.api.post(getApiUrl,values) :
    this.api.put(getApiUrl,values)
   }

   onBack()
   {
    this.router.navigate(['/product-list']);
   }
}
