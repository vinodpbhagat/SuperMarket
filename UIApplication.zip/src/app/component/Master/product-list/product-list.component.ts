import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';
import { NavigationExtras, Router } from '@angular/router';
import { deleteProductUrl, getProductsUrl } from 'src/app/service/api.urls';
import { Product } from 'src/app/models/Product';
import { ProductService } from 'src/app/service/product.service';
import { CartService } from 'src/app/service/cart.service';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
  products:any
  constructor(private apiService : ApiService,
    private router: Router ,private productService : ProductService ,private cartService : CartService) {

      this.cartService.setCart(false);
    }
  ngOnInit(): void {
    this.getProductList();
  }
  getProductList(){
    this.apiService.get(getProductsUrl)
    .subscribe(res=>{
      this.products = res;
    });
  }
  removeItem(item:Product)
  {
    this.apiService.delete(deleteProductUrl,item.id)
    .subscribe(res=>{
      console.log("res",res)
    });
    this.products.map((a:any, index:any)=>{
      if(item.id=== a.id){
        this.products.splice(index,1);
      }
    });


  }
  updateProduct(item:Product)
  {
    this.productService.productData.next(item)
    this.router.navigate(['/add']);
  }
}
