import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';
import { getProductsUrl } from 'src/app/service/api.urls';
import { CartService } from 'src/app/service/cart.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {

  public productList : any ;
  public filterCategory : any
  constructor(private apiService : ApiService, private cartService : CartService) {

    this.cartService.setCart(true);
   }

  ngOnInit(): void {
    this.apiService.get(getProductsUrl)
    .subscribe(res=>{
      this.productList = res;
      this.filterCategory = res;
      this.productList.forEach((a:any) => {
        if(a.category ==="Fashion" || a.category ==="Fashion"){
          a.category ="Fashion"
        }
        Object.assign(a,{quantity:1,total:a.price});
      });
      console.log(this.productList)
    });
  }
  addtocart(item: any){
    this.cartService.addtoCart(item);
  }
  filter(category:string){
    this.filterCategory = this.productList
    .filter((a:any)=>{
      if(a.categoryName == category || category==''){
        return a;
      }
    })
  }

}
