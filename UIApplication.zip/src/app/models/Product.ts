export interface Product {
    id: number;
    categoryName: string;
    title: string;
    description: string;
    price: number;
   }
