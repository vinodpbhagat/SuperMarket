export interface ResponseModel {
  statusCode: number;
  message: string;
 }
