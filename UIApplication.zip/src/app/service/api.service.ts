import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {catchError, map} from 'rxjs/operators';
import { Product } from '../models/Product';
import { ResponseModel } from '../models/ResponseModel';

import { environment } from '../../environments/environment';
import { throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ApiService {
   API_URL  = environment.apiUrl;
  constructor(private http : HttpClient) { }
  get(url:string){
    return this.http.get<Product>(`${environment.apiUrl}`+url)
    .pipe(
      catchError(this.handleError),
      map((res:any)=>{
      return res;
      })
    )
  }
  post(url:string,requestPayload:Product){
    return this.http.post<ResponseModel>(`${environment.apiUrl}`+url
    ,requestPayload)
    .pipe(catchError(this.handleError),map((res:any)=>{
      return res;
    }))
  }
  put(url:string,requestPayload:Product){
    return this.http.put<ResponseModel>(`${environment.apiUrl}`+url
    ,requestPayload)
    .pipe(catchError(this.handleError),map((res:any)=>{
      return res;
    }))
  }
  delete(url:string,id:number){
    return this.http.delete<ResponseModel>(`${environment.apiUrl}`+ url + id
    )
    .pipe(catchError(this.handleError),map((res:any)=>{
      return res;
    }))
  }

handleError(err: any) {
  let errorMessage: string;
  if (err.error instanceof ErrorEvent) {
    errorMessage = `An error occurred: ${err?.error?.message}`;
  } else {
    errorMessage = `Error -  ${err?.status}: ${err?.error
      ?.message}`;
  }
  return throwError(errorMessage);
}
}
