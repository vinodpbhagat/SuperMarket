export const getProductsUrl = 'Product/GetProducts';
export const addProductUrl = 'Product/AddProduct';
export const updateProductUrl = 'Product/UpdateProduct';
export const deleteProductUrl = 'Product/DeleteProduct/';
