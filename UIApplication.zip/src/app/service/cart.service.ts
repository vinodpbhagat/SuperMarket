import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  public cartItemList : any =[]
  public productList = new BehaviorSubject<any>([]);
  public isCartDisplay = new BehaviorSubject<boolean>(true);
  constructor() { }
  getProducts(){
    return this.productList.asObservable();
  }
  setProduct(product : any){
    this.cartItemList.push(...product);
    this.productList.next(product);
  }
  addtoCart(product : any){
    let isPresent = this.toArray(this.cartItemList).findIndex(x => x.id == product.id);
    if (isPresent == -1) {
      this.cartItemList.push(product);
      this.productList.next(this.cartItemList);
      this.getTotalPrice();
    }
  }
  getTotalPrice() : number{
    let grandTotal = 0;
    this.cartItemList.map((a:any)=>{
      grandTotal += a.total;
    })
    return  parseFloat(grandTotal?.toFixed(2));
  }
  removeCartItem(product: any){
    this.cartItemList.map((a:any, index:any)=>{
      if(product.id=== a.id){
        this.cartItemList.splice(index,1);
      }
    })
    this.productList.next(this.cartItemList);
  }
  removeAllCart(){
    this.cartItemList = []
    this.productList.next(this.cartItemList);
  }

  updateCart(product : any, qty :number){
    if (typeof qty === 'number' ) {
        let itemIndex = this.toArray(this.cartItemList).findIndex(x => x.id == product.id);
      this.cartItemList[itemIndex]["quantity"]=qty;
      let calculateTotal = qty * this.cartItemList[itemIndex]["price"];
      this.cartItemList[itemIndex]["total"] = calculateTotal
      this.productList.next(this.cartItemList);
      this.getTotalPrice();

    }
  }

  toArray = <T>(arg: T | T[]): T[] => {
    return Array.isArray(arg) ? arg : [arg];
  };

  setCart(value:boolean)
  {
    this.isCartDisplay.next(value);
  }
  getCart(){
    return this.isCartDisplay.asObservable();
  }

}
