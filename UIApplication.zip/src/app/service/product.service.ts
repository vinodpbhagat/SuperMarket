import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { Product } from '../models/Product';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  productData = new BehaviorSubject<Product | null>(null);

  constructor() {}

  getProductData(): Observable<Product | null> {
    return this.productData;
  }
}
